// $Id$

Installing Api.Ai in Drupal 7.x:

1. Upload `Api.Ai` directory to `/sites/all/modules/`.
2. Open your Drupal website.
3. Go to "Administration > Modules" and activate `MyLiveChat` module (under `Other` category).
4.  Get your secret key from https://api.ai/ . add it ti api module.
5. You can see a help icon on left Side of you site. By clicking on on it chat works




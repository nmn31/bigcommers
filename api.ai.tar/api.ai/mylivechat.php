<?php
$mylivechat_id = variable_get('mylivechat_id');

?>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Title</title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<script>
/**
 * Copyright 2017 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

var ApiAi =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/target/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 8);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {



Object.defineProperty(exports, "__esModule", { value: true });
var ApiAiConstants;
(function (ApiAiConstants) {
    var AVAILABLE_LANGUAGES;
    (function (AVAILABLE_LANGUAGES) {
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["EN"] = "en"] = "EN";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["DE"] = "de"] = "DE";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ES"] = "es"] = "ES";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["PT_BR"] = "pt-BR"] = "PT_BR";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_HK"] = "zh-HK"] = "ZH_HK";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_CN"] = "zh-CN"] = "ZH_CN";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["ZH_TW"] = "zh-TW"] = "ZH_TW";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["NL"] = "nl"] = "NL";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["FR"] = "fr"] = "FR";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["IT"] = "it"] = "IT";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["JA"] = "ja"] = "JA";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["KO"] = "ko"] = "KO";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["PT"] = "pt"] = "PT";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["RU"] = "ru"] = "RU";
        AVAILABLE_LANGUAGES[AVAILABLE_LANGUAGES["UK"] = "uk"] = "UK";
    })(AVAILABLE_LANGUAGES = ApiAiConstants.AVAILABLE_LANGUAGES || (ApiAiConstants.AVAILABLE_LANGUAGES = {}));
    ApiAiConstants.VERSION = "2.0.0-beta.20";
    ApiAiConstants.DEFAULT_BASE_URL = "https://api.api.ai/v1/";
    ApiAiConstants.DEFAULT_API_VERSION = "20150910";
    ApiAiConstants.DEFAULT_CLIENT_LANG = AVAILABLE_LANGUAGES.EN;
})(ApiAiConstants = exports.ApiAiConstants || (exports.ApiAiConstants = {}));


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var ApiAiBaseError = (function (_super) {
    __extends(ApiAiBaseError, _super);
    function ApiAiBaseError(message) {
        var _this = _super.call(this, message) || this;
        _this.message = message;
        _this.stack = new Error().stack;
        return _this;
    }
    return ApiAiBaseError;
}(Error));
exports.ApiAiBaseError = ApiAiBaseError;
var ApiAiClientConfigurationError = (function (_super) {
    __extends(ApiAiClientConfigurationError, _super);
    function ApiAiClientConfigurationError(message) {
        var _this = _super.call(this, message) || this;
        _this.name = "ApiAiClientConfigurationError";
        return _this;
    }
    return ApiAiClientConfigurationError;
}(ApiAiBaseError));
exports.ApiAiClientConfigurationError = ApiAiClientConfigurationError;
var ApiAiRequestError = (function (_super) {
    __extends(ApiAiRequestError, _super);
    function ApiAiRequestError(message, code) {
        if (code === void 0) { code = null; }
        var _this = _super.call(this, message) || this;
        _this.message = message;
        _this.code = code;
        _this.name = "ApiAiRequestError";
        return _this;
    }
    return ApiAiRequestError;
}(ApiAiBaseError));
exports.ApiAiRequestError = ApiAiRequestError;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Errors_1 = __webpack_require__(1);
var XhrRequest_1 = __webpack_require__(7);
var Request = (function () {
    function Request(apiAiClient, options) {
        this.apiAiClient = apiAiClient;
        this.options = options;
        this.uri = this.apiAiClient.getApiBaseUrl() + "query?v=" + this.apiAiClient.getApiVersion();
        this.requestMethod = XhrRequest_1.default.Method.POST;
        this.headers = {
            Authorization: "Bearer " + this.apiAiClient.getAccessToken(),
        };
        console.log(this.uri);

        this.options.lang = this.apiAiClient.getApiLang();
        this.options.sessionId = this.apiAiClient.getSessionId();
        console.log(this.headers);
        console.log(this.options.lang);
        console.log(this.options.sessionId);
    }
    Request.handleSuccess = function (xhr) {
        return Promise.resolve(JSON.parse(xhr.responseText));
    };
    Request.handleError = function (xhr) {
        var error = new Errors_1.ApiAiRequestError(null);
        try {
            var serverResponse = JSON.parse(xhr.responseText);
            if (serverResponse.status && serverResponse.status.errorDetails) {
                error = new Errors_1.ApiAiRequestError(serverResponse.status.errorDetails, serverResponse.status.code);
            }
            else {
                error = new Errors_1.ApiAiRequestError(xhr.statusText, xhr.status);
            }
        }
        catch (e) {
            error = new Errors_1.ApiAiRequestError(xhr.statusText, xhr.status);
        }
        return Promise.reject(error);
    };
    Request.prototype.perform = function (overrideOptions) {
        if (overrideOptions === void 0) { overrideOptions = null; }
        var options = overrideOptions ? overrideOptions : this.options;
        return XhrRequest_1.default.ajax(this.requestMethod, this.uri, options, this.headers)
            .then(Request.handleSuccess.bind(this))
            .catch(Request.handleError.bind(this));
    };
    return Request;
}());
exports.default = Request;


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
var ApiAiConstants_1 = __webpack_require__(0);
var Errors_1 = __webpack_require__(1);
var EventRequest_1 = __webpack_require__(5);
var TextRequest_1 = __webpack_require__(6);
__export(__webpack_require__(4));
var ApiAiConstants_2 = __webpack_require__(0);
exports.ApiAiConstants = ApiAiConstants_2.ApiAiConstants;
var ApiAiClient = (function () {
    function ApiAiClient(options) {
        if (!options || !options.accessToken) {
            throw new Errors_1.ApiAiClientConfigurationError("Access token is required for new ApiAi.Client instance");
        }
        this.accessToken = options.accessToken;
        this.apiLang = options.lang || ApiAiConstants_1.ApiAiConstants.DEFAULT_CLIENT_LANG;
        this.apiVersion = options.version || ApiAiConstants_1.ApiAiConstants.DEFAULT_API_VERSION;
        this.apiBaseUrl = options.baseUrl || ApiAiConstants_1.ApiAiConstants.DEFAULT_BASE_URL;
        this.sessionId = options.sessionId || this.guid();
    }
    ApiAiClient.prototype.textRequest = function (query, options) {
        if (options === void 0) { options = {}; }
        if (!query) {
            throw new Errors_1.ApiAiClientConfigurationError("Query should not be empty");
        }
        options.query = query;
        return new TextRequest_1.default(this, options).perform();
    };
    ApiAiClient.prototype.eventRequest = function (eventName, eventData, options) {
        if (eventData === void 0) { eventData = {}; }
        if (options === void 0) { options = {}; }
        if (!eventName) {
            throw new Errors_1.ApiAiClientConfigurationError("Event name can not be empty");
        }
        options.event = { name: eventName, data: eventData };
        return new EventRequest_1.EventRequest(this, options).perform();
    };
    // @todo: implement local tts request
    /*public ttsRequest(query) {
        if (!query) {
            throw new ApiAiClientConfigurationError("Query should not be empty");
        }
        return new TTSRequest(this).makeTTSRequest(query);
    }*/
    /*public userEntitiesRequest(options: IRequestOptions = {}): UserEntitiesRequest {
        return new UserEntitiesRequest(this, options);
    }*/
    ApiAiClient.prototype.getAccessToken = function () {
        return this.accessToken;
    };
    ApiAiClient.prototype.getApiVersion = function () {
        return (this.apiVersion) ? this.apiVersion : ApiAiConstants_1.ApiAiConstants.DEFAULT_API_VERSION;
    };
    ApiAiClient.prototype.getApiLang = function () {
        return (this.apiLang) ? this.apiLang : ApiAiConstants_1.ApiAiConstants.DEFAULT_CLIENT_LANG;
    };
    ApiAiClient.prototype.getApiBaseUrl = function () {
        return (this.apiBaseUrl) ? this.apiBaseUrl : ApiAiConstants_1.ApiAiConstants.DEFAULT_BASE_URL;
    };
    ApiAiClient.prototype.setSessionId = function (sessionId) {
        this.sessionId = sessionId;
    };
    ApiAiClient.prototype.getSessionId = function () {
        return this.sessionId;
    };
    /**
     * generates new random UUID
     * @returns {string}
     */
    ApiAiClient.prototype.guid = function () {
        var s4 = function () { return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1); };
        return s4() + s4() + "-" + s4() + "-" + s4() + "-" +
            s4() + "-" + s4() + s4() + s4();
    };
    return ApiAiClient;
}());
exports.ApiAiClient = ApiAiClient;


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var IStreamClient;
(function (IStreamClient) {
    var ERROR;
    (function (ERROR) {
        ERROR[ERROR["ERR_NETWORK"] = 0] = "ERR_NETWORK";
        ERROR[ERROR["ERR_AUDIO"] = 1] = "ERR_AUDIO";
        ERROR[ERROR["ERR_SERVER"] = 2] = "ERR_SERVER";
        ERROR[ERROR["ERR_CLIENT"] = 3] = "ERR_CLIENT";
    })(ERROR = IStreamClient.ERROR || (IStreamClient.ERROR = {}));
    var EVENT;
    (function (EVENT) {
        EVENT[EVENT["MSG_WAITING_MICROPHONE"] = 0] = "MSG_WAITING_MICROPHONE";
        EVENT[EVENT["MSG_MEDIA_STREAM_CREATED"] = 1] = "MSG_MEDIA_STREAM_CREATED";
        EVENT[EVENT["MSG_INIT_RECORDER"] = 2] = "MSG_INIT_RECORDER";
        EVENT[EVENT["MSG_RECORDING"] = 3] = "MSG_RECORDING";
        EVENT[EVENT["MSG_SEND"] = 4] = "MSG_SEND";
        EVENT[EVENT["MSG_SEND_EMPTY"] = 5] = "MSG_SEND_EMPTY";
        EVENT[EVENT["MSG_SEND_EOS_OR_JSON"] = 6] = "MSG_SEND_EOS_OR_JSON";
        EVENT[EVENT["MSG_WEB_SOCKET"] = 7] = "MSG_WEB_SOCKET";
        EVENT[EVENT["MSG_WEB_SOCKET_OPEN"] = 8] = "MSG_WEB_SOCKET_OPEN";
        EVENT[EVENT["MSG_WEB_SOCKET_CLOSE"] = 9] = "MSG_WEB_SOCKET_CLOSE";
        EVENT[EVENT["MSG_STOP"] = 10] = "MSG_STOP";
        EVENT[EVENT["MSG_CONFIG_CHANGED"] = 11] = "MSG_CONFIG_CHANGED";
    })(EVENT = IStreamClient.EVENT || (IStreamClient.EVENT = {}));
})(IStreamClient = exports.IStreamClient || (exports.IStreamClient = {}));


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Request_1 = __webpack_require__(2);
var EventRequest = (function (_super) {
    __extends(EventRequest, _super);
    function EventRequest() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return EventRequest;
}(Request_1.default));
exports.EventRequest = EventRequest;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Request_1 = __webpack_require__(2);
var TextRequest = (function (_super) {
    __extends(TextRequest, _super);
    function TextRequest() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return TextRequest;
}(Request_1.default));
exports.default = TextRequest;


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * quick ts implementation of example from
 * https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/Promise
 * with some minor improvements
 * @todo: test (?)
 * @todo: add node.js implementation with node's http inside. Just to make SDK cross-platform
 */
var XhrRequest = (function () {
    function XhrRequest() {
    }
    // Method that performs the ajax request
    XhrRequest.ajax = function (method, url, args, headers, options) {
        if (args === void 0) { args = null; }
        if (headers === void 0) { headers = null; }
        if (options === void 0) { options = {}; }
        // Creating a promise
        return new Promise(function (resolve, reject) {
            // Instantiates the XMLHttpRequest
            var client = XhrRequest.createXMLHTTPObject();
            var uri = url;
            var payload = null;
            // Add given payload to get request
            if (args && (method === XhrRequest.Method.GET)) {
                uri += "?";
                var argcount = 0;
                for (var key in args) {
                    if (args.hasOwnProperty(key)) {
                        if (argcount++) {
                            uri += "&";
                        }
                        uri += encodeURIComponent(key) + "=" + encodeURIComponent(args[key]);
                    }
                }
            }
            else if (args) {
                if (!headers) {
                    headers = {};
                }
                headers["Content-Type"] = "application/json; charset=utf-8";
                payload = JSON.stringify(args);
            }
            for (var key in options) {
                if (key in client) {
                    client[key] = options[key];
                }
            }
            // hack: method[method] is somewhat like .toString for enum Method
            // should be made in normal way
            client.open(XhrRequest.Method[method], uri, true);
            // Add given headers
            if (headers) {
                for (var key in headers) {
                    if (headers.hasOwnProperty(key)) {
                        client.setRequestHeader(key, headers[key]);
                    }
                }
            }
            payload ? client.send(payload) : client.send();
            client.onload = function () {
                if (client.status >= 200 && client.status < 300) {
                    // Performs the function "resolve" when this.status is equal to 2xx
                    resolve(client);
                }
                else {
                    // Performs the function "reject" when this.status is different than 2xx
                    reject(client);
                }
            };
            client.onerror = function () {
                reject(client);
            };
        });
    };
    XhrRequest.get = function (url, payload, headers, options) {
        if (payload === void 0) { payload = null; }
        if (headers === void 0) { headers = null; }
        if (options === void 0) { options = {}; }
        return XhrRequest.ajax(XhrRequest.Method.GET, url, payload, headers, options);
    };
    XhrRequest.post = function (url, payload, headers, options) {
        if (payload === void 0) { payload = null; }
        if (headers === void 0) { headers = null; }
        if (options === void 0) { options = {}; }
        return XhrRequest.ajax(XhrRequest.Method.POST, url, payload, headers, options);
    };
    XhrRequest.put = function (url, payload, headers, options) {
        if (payload === void 0) { payload = null; }
        if (headers === void 0) { headers = null; }
        if (options === void 0) { options = {}; }
        return XhrRequest.ajax(XhrRequest.Method.PUT, url, payload, headers, options);
    };
    XhrRequest.delete = function (url, payload, headers, options) {
        if (payload === void 0) { payload = null; }
        if (headers === void 0) { headers = null; }
        if (options === void 0) { options = {}; }
        return XhrRequest.ajax(XhrRequest.Method.DELETE, url, payload, headers, options);
    };
    XhrRequest.createXMLHTTPObject = function () {
        var xmlhttp = null;
        for (var _i = 0, _a = XhrRequest.XMLHttpFactories; _i < _a.length; _i++) {
            var i = _a[_i];
            try {
                xmlhttp = i();
            }
            catch (e) {
                continue;
            }
            break;
        }
        return xmlhttp;
    };
    XhrRequest.XMLHttpFactories = [
        function () { return new XMLHttpRequest(); },
        function () { return new window["ActiveXObject"]("Msxml2.XMLHTTP"); },
        function () { return new window["ActiveXObject"]("Msxml3.XMLHTTP"); },
        function () { return new window["ActiveXObject"]("Microsoft.XMLHTTP"); }
    ];
    return XhrRequest;
}());
(function (XhrRequest) {
    var Method;
    (function (Method) {
        Method[Method["GET"] = "GET"] = "GET";
        Method[Method["POST"] = "POST"] = "POST";
        Method[Method["PUT"] = "PUT"] = "PUT";
        Method[Method["DELETE"] = "DELETE"] = "DELETE";
    })(Method = XhrRequest.Method || (XhrRequest.Method = {}));
})(XhrRequest || (XhrRequest = {}));
exports.default = XhrRequest;


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(3);


/***/ })
/******/ ]);
//# sourceMappingURL=ApiAi.js.map




/**
 * Copyright 2017 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * All this stuff is moved into global namespace and separate files just to be
 * MAXIMUM clear and easy to understand
 */

var client;
client = new ApiAi.ApiAiClient({accessToken: "<?php echo $mylivechat_id; ?> "});
function sendText(text) {
  return client.textRequest(text);
}

</script>
<style>
 #edit-mylivechat-id{
        padding: 6px;
        border: 1px solid #ccc;
        border-top-color: #999;
        background: #fff;
        color: #333;
        width: 248px;
        }

        .chat-header .fa.fa-close{
            position: absolute;
            right: 28px;
            font-size: 20px;
            top: 9px;
            cursor: pointer;
        }
        .chat-btn{
            position: fixed;
            right: 25px;
            top: 60px;
            cursor: pointer;
        }

        .chat-btn > div, .chat-left {
            position: relative;
        }

        .chat-btn > div > span, .chat-left > span{
            position: absolute;
            top: 10px;
            left: 7px;
            color: #FFF;
            font-size: 12px;
        }


        .chat-left > span{
            position: absolute;
            top: 15px;
            left: 12px;
            color: #FFF;
            font-size: 12px;
        }

        .chat-box{
            position: fixed;
            top: 0;
            right: 0;
            width: 300px;
            height: 350px;
            border: 1px solid #8e8e8e;
            overflow: hidden;
            box-shadow: 0px 0px 10px #555;
            display: none;
            z-index: 999;
            background: #FFF;
        }
        .chat-box .chat-header{
            width:100%;
            padding: 10px;
            border-bottom: 1px solid #8e8e8e;
            position: relative;
        }
        .chat-box .chat-body{
            overflow-y: auto;
            height: 275px;
        }
        .chat-box .chat-footer{
            width:100%;
            padding: 2px;
            border-top: 1px solid #8e8e8e;
            position: absolute;
            bottom: 0px;
            left:0px;
            background: #fff;
        }
        .chat-box input{
            border: none;
            width: 100%;
            height: 30px;
        }
        .chat-left{
            float: left;

            padding: 5px;
        }
        .chat-right{
            margin-left: 50px;

        }
        .chat-right ul{
            list-style-type: none;
            margin-right:15px;
        }
        .chat-right ul li{
            border: 1px solid #666;
            margin: 8px 0;
            padding: 4px 5px;
            border-radius: 5px;
            box-shadow: 0px 0px 5px #ccc;
            overflow: hidden;
            font-size: 14px;
        }

        .chat-right ul li:hover{
            cursor: pointer;
            background: #e5e5e5;
        }
        .chat-right ul li.active{
            background-color: #ccc;
        }

        .chat-right.sub{
            display: none;
        }

        #map{
            width:100%;
            height:100px;
        }
        .social{
            display: none;
        }
        .social ul {
            margin: 0px;
            padding: 1px;
        }
        .social ul li{
            position: relative;
        }
        .social, .social ul li, .social ul{
            box-shadow: none !important;
            border: none !important;
        }
        li.social:hover{
            background-color: none;
        }
        .social .fa{
            color: #2196F3;
            font-size: 28px;
            display: inline-block;
            position: absolute;
            top: 8px;
        }
        .social span{
            display: block;
            padding-left: 35px;
        }
        .remove-border{
            border: none !important;
            box-shadow: none !important;
        }
    #placeholder {
        text-align: center;
        margin-top: 1.5em;
    }

    .clearfix {
        clear: both;
    }
	.green.accent-1 {
		background-color: #B9F6CA !important;
	}
	.blue-text.text-darken-2 {
    color: #1976D2 !important;
}
.right-align {
    text-align: right;
}
	.left {
    float: left !important;
}

	.card-panel {
    transition: box-shadow .25s;
    padding: 20px;
    margin: 0.5rem 0 1rem 0;
    border-radius: 2px;
    background-color: #fff;
}
</style>
<script>
function show(){

	$(".chat-box").show();
}
function hide(){

	$(".chat-box").hide();
}
var wage = document.getElementById("q");
wage.addEventListener("keydown", function (e) {
    if (e.keyCode === 13) {  //checks whether the pressed key is "Enter"
        validate(e);
    }
});

function d(e){
	 if (e.keyCode === 13) {  //checks whether the pressed key is "Enter"
        var elem = document.getElementById('chatdata');
        setTimeout(function(){ elem.scrollTop = elem.scrollHeight; }, 30);
        setTimeout(function(){ elem.scrollTop = elem.scrollHeight; }, 3000);

    }
}

function validate(e) {
	alert('ss');
    var elem = document.getElementById('chatdata');
    elem.scrollTop = elem.scrollHeight;

}
</script>
<script async="" defer="" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCSvqj7eXj6wrlojzJLeyDs62-tYspbbcA"></script>
<script>


</script>
<link type="text/css" rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" media="all">
<div class="chat-btn" style="">
<div onclick ="show()">
	<i class="fa fa-comment fa-3x"></i><span>Help</span>
</div>
 </div>
<div class="chat-box" style="display: none;">
          <div class="chat-header">
              <span><b>Robot du Grand Palais</b></span>
              <i onclick ="hide()" class="fa fa-close fa-2x"></i>
          </div>

          <div id ="chatdata" class="chat-body">
              <div class="chat-left">
                  <i class="fa fa-comment fa-3x"></i><span>Aide</span>
              </div>
              <div class="chat-right main">
                <div>
                <ul id="result">

                </ul>
                </div>
              </div>

              <div class="chat-right sub" style="display: none;">

                  <ul >

                      <li class=" active click-map-content">
                          <div id = "map-msg">

                          </div>
                          <div id="map"></div>
                      </li>
                      <li id ="pdfcontent1" class=" active click-pdf-content">
                          Voici les détails du programme des cours d'histoire de l'art:
                      </li>
                      <li  class="click-pdf-content remove-border">
                          <a id ="pdfcontent2" href="" target="_blank"><i class="fa fa-file-pdf-o" style="font-size:40px"></i></a>
                      </li>
                      <li class=" active social" style="display: list-item;">
                          <ul>
                              <li><i class="fa fa-facebook-official"></i><span>Posez-nous vos questions sur Facebook</span></li>
                              <li><i class="fa fa-comment"></i> <span>Posez-nous vos questions sur Messenger</span></li>
                              <li><i class="fa fa-twitter-square"></i> <span>Posez-nous vos questions sur Twitter</span></li>
                              <li><i class="fa fa-phone"></i> <span>Appelez-nous</span></li>
                          </ul>
                      </li>
                  </ul>

              </div>
          </div>

          <div class="chat-footer">
              <input onkeypress="d(event)" type="text" id="q" name="msg" placeholder="Saisissez votre message..">
          </div>
      </div>
<script>

/**
 * Copyright 2017 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

(function() {
  "use strict";

  var ENTER_KEY_CODE = 13;
  var queryInput, resultDiv, accessTokenInput;

  window.onload = init;

  function init() {
     queryInput = document.getElementById("q");
     resultDiv = document.getElementById("result");
     accessTokenInput = document.getElementById("access_token");
     var setAccessTokenButton = document.getElementById("set_access_token");
     queryInput.addEventListener("keydown", queryInputKeyDown);
     var value = "StartChat";
     sendText(value)
      .then(function(response) {
        var result;
        console.log(response.result.fulfillment.messages[0]['payload']['custom-payload'][0]['pdf-msg']);
        document.getElementById("pdfcontent1").innerHTML=response.result.fulfillment.messages[0]['payload']['custom-payload'][0]['pdf-msg'];
        document.getElementById("map-msg").innerHTML=response.result.fulfillment.messages[0]['payload']['custom-payload'][0]['map-msg'];
        var pdfurl = document.getElementById("pdfcontent2");
        pdfurl.setAttribute("href", response.result.fulfillment.messages[0]['payload']['custom-payload'][0]['pdf-url']);
        initMap(response.result.fulfillment.messages[0]['payload']['custom-payload'][0]['lat'], response.result.fulfillment.messages[0]['payload']['custom-payload'][0]['lng']);
      });
  }

  function setAccessToken() {
    document.getElementById("placeholder").style.display = "none";
    document.getElementById("main-wrapper").style.display = "block";
    window.init(accessTokenInput.value);
  }


  function initMap(lat,lng) {
      var uluru = {lat, lng};
      var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 4,
          center: uluru
      });

      var marker = new google.maps.Marker({
          position: uluru,
          map: map
      });
  }


              $(document).ready(function () {

                  $(document).on('click', '.chat-btn', function () {
                      init();
                      $('.chat-btn').fadeOut(200);
                      $('.chat-box').fadeIn(200);

                      $('.chat-right.main').show();

                      $('.chat-right.sub > ul > li').show();
                      $('.chat-right.sub').hide();


                  });

                  $(document).on('click', '.chat-header .fa-close', function () {
                      init();
                      $('.chat-btn').fadeIn(200);
                      $('.chat-box').fadeOut(200);
                  });

                  $(document).on('click', '.chat-right .click', function () {
                      init();
                      $('.chat-right.main').hide();
                      $('.chat-right.sub').show();
                      $('.chat-right.sub > ul > li').hide();
                      $('.chat-right.sub li').not('.click-map-content').not('.click-pdf-content').not('.social').show();
                  });

                  $(document).on('click', '.chat-right .click-map', function () {
                      init();
                      $('.chat-right.main').hide();
                      $('.chat-right.sub').show();
                      $('.chat-right.sub > ul > li').hide();
                      $('.chat-right.sub li.click-map-content').show();

                  });

                  $(document).on('click', '.chat-right .click-pdf', function () {
                      init();
                      $('.chat-right.main').hide();
                      $('.chat-right.sub').show();
                      $('.chat-right.sub > ul > li').hide();
                      $('.chat-right.sub li.click-pdf-content').show();
                  });

                  $(document).on('click', '.chat-right .click-social', function () {
                      init();
                      $('.chat-right.main').hide();
                      $('.chat-right.sub').show();
                      $('.chat-right.sub > ul > li').hide();
                      $('.chat-right.sub li.social').show();
                  });

                  $('input[name="msg"]').keypress(function (e) {
                      if (e.which == 13) {
                          //$('.chat-right.main').hide();
                          $('.chat-right').show();
                          //$('.chat-right.sub > ul > li').hide();
                          $('.chat-right.sub .user_type').show();
                          $('.click-pdf-content').hide();
                          $('.click-map-content').hide();
                          $('.social').hide();

                          $(this).val('');

                      }
                  });

              });




  function queryInputKeyDown(event) {
    if (event.which !== ENTER_KEY_CODE) {
      return;
    }

    var value = queryInput.value;
    queryInput.value = "";

    createQueryNode(value);
    var responseNode = createResponseNode();

    sendText(value)
      .then(function(response) {
        var result;
        try {
          result = response.result.fulfillment.speech
        } catch(error) {
          result = "";
        }
        setResponseJSON(response);
        setResponseOnNode(result, responseNode);
      })
      .catch(function(err) {
        setResponseJSON(err);
        setResponseOnNode("Something goes wrong", responseNode);
      });
  }

  function createQueryNode(query) {
    var node = document.createElement('li');
    node.className = "user_type";
    node.innerHTML = query;
    resultDiv.appendChild(node);
  }
  function createQueryNode1() {

    var node = document.getElementById('result');
    node.className = "user_type";
    node.innerHTML += '<li style="border-radius:150px;background-color: lavenderblush;width: 146px" class="click-pdf">The Art Courses Program</li><li style="border-radius:150px;background-color: lavenderblush;width: 146px" class="click-map">Where and with whom?</li><li style="border-radius:150px;background-color: lavenderblush;width: 146px" class="click">ask your questions</li><li style="border-radius:150px;background-color: lavenderblush;width: 146px"  class="click-social">Contact U.S</li>';
  }

  function createResponseNode() {
    var node = document.createElement('li');
    node.className = "active user_type";
    node.innerHTML = "...";
    resultDiv.appendChild(node);
    return node;
  }
  var count= 0;
  function setResponseOnNode(response, node) {
    console.log('response');

    if(count == 0){
      node.innerHTML = response ? response : "[empty response]";
      createQueryNode1();
    }else{
      console.log(count);
      node.innerHTML += response ? response : "[empty response]";
      node.setAttribute('data-actual-response', response);
    }
    count = count +1;

  }

  function setResponseJSON(response) {
    //  var node = document.getElementById("jsonResponse");
    //node.innerHTML = JSON.stringify(response, null, 2);
  }

  function sendRequest() {

  }

})();

</script>

<?php
// $Id$

/**
 * @file
 * MyLiveChat module for Drupal
 */
class mylivechat
{
  /**
   * Singleton pattern
   */
  protected static $instance = NULL;

  /**
   * Module directory
   */
  protected $module_dir = NULL;

  /**
   * Singleton pattern
   */
  public static function get_instance()
  {
    if (is_null(self::$instance))
    {
      self::$instance = new mylivechat();
    }

    return self::$instance;
  }

  /**
   * Constructor
   */
  protected function __construct()
  {
    $this->module_dir = drupal_get_path('module', 'mylivechat');
  }

  /**
   * Resets module settings
   */
  public function reset_settings()
  {
    variable_del('mylivechat_id');
    variable_del('mylivechat_displaytype');
    variable_del('mylivechat_membership');
    variable_del('mylivechat_encrymode');
    variable_del('mylivechat_encrykey');
  }

  /**
   * License number validation
   */
  public function validate_id($mylivechatid)
  {
    $license = (int)$mylivechatid;
	if ($license === 0) return false;

    return preg_match('/^[0-9]{8}$/', $license);
  }

  /**
   * Checks if MyLiveChat settings are properly set up
   */
  public function is_installed()
  {
	$mylivechat_id = variable_get('mylivechat_id');
	$mylivechat_displaytype = variable_get('mylivechat_displaytype');
	$mylivechat_membership = variable_get('mylivechat_membership');
	$mylivechat_encrymode = variable_get('mylivechat_encrymode');
	$mylivechat_encrykey = variable_get('mylivechat_encrykey');

	$isIntegrateUser = false;
	if($mylivechat_membership == "yes")
	{
		$isIntegrateUser = true;
	}

	if (is_null($mylivechat_id)) return FALSE;

    if ($this->validate_id($mylivechat_id) == FALSE) return FALSE;

    return TRUE;
  }

  /**
   * Checks if MyLiveChat tracking code is installed properly
   */
  public function tracking_code_installed()
  {
    if ($this->is_installed() == FALSE) return FALSE;

    return TRUE;
  }

  /**
   * Checks if LiveChat button code is installed properly
   */
  public function chat_button_installed()
  {
    if ($this->is_installed() == FALSE) return FALSE;

	//$theme = variable_get('theme_default','none');

    // Check `status` value for `chat-button` block
    $result = db_query('SELECT status FROM {block} WHERE module=:module', array(':module' => 'mylivechat'));
	$row = $result->fetchObject();

    if (!$row || $row->status != '1') return FALSE;

    return TRUE;
  }

  public function install_codes()
  {
	$this->add_tracking_code();
  }
  /**
   * Install tracking code
   */
  public function add_tracking_code()
  {
    if ($this->is_installed() == FALSE) return FALSE;
  }

  /**
   * Returns MyLiveChat button HTML code
   */


  public function include_admin_css()
  {
  }

  public function include_admin_js()
  {
    drupal_add_js($this->module_dir . '/js/jquery-1.6.min.js');
    drupal_add_js($this->module_dir . '/js/mylivechat.js');
  }

	public function GetEncrypt($data, $encrymode,$encrykey)
	{
		if($encrymode=="basic")
			return $this->BasicEncrypt($data,$encrykey);
		return $data;
	}

	public function BasicEncrypt($data, $encryptkey)
	{
		$EncryptLoopCount = 4;

		$vals = $this->MakeArray($data, true);
		$keys = $this->MakeArray($encryptkey, false);

		$len = sizeof($vals);
		$len2 = sizeof($keys);

		for ($t = 0; $t < $EncryptLoopCount; $t++)
		{
			for ($i = 0; $i < $len; $i++)
			{
				$v = $vals[$i];
				$im = ($v + $i) % 5;

				for ($x = 0; $x < $len; $x++)
				{
					if ($x == $i)
						continue;
					if ($x % 5 != $im)
						continue;

					for ($y = 0; $y <$len2; $y++)
					{
						$k = $keys[$y];
						if ($k == 0)
							continue;

						$vals[$x] += $v % $k;
					}
				}
			}
		}
		return implode('-', $vals);
	}

	public function MakeArray($str, $random)
	{
		$len = pow(2, floor(log(strlen($str), 2)) + 1) + 8;
		if ($len < 32) $len = 32;

		$arr = Array();
		$strarr = str_split($str);
		if ($random==true)
		{
			for ($i = 0; $i < $len; $i++)
				$arr[] = ord($strarr[rand() % strlen($str)]);

			$start = 1 + rand() % ($len - strlen($str) - 2);

			for ($i = 0; $i < strlen($str); $i++)
				$arr[$start + $i] = ord($strarr[$i]);

			$arr[$start - 1] = 0;
			$arr[$start + strlen($str)] = 0;
		}
		else
		{
			for ($i = 0; $i < $len; $i++)
				$arr[] = ord($strarr[$i % strlen($str)]);
		}

		return $arr;
	}

	public function EncodeJScript($str)
	{
		$chars="0123456789ABCDEF";
		$chars = str_split($chars);

		$sb = "";
		$l = strlen($str);
		$strarr = str_split($str);
		for ($i = 0; $i < $l; $i++)
		{
			$c = $strarr[$i];
			if ($c == '\\' || $c == '"' || $c == '\'' || $c == '>' || $c == '<' || $c == '&' || $c == '\r' || $c == '\n')
			{
				if ($sb == "")
				{
					if ($i > 0)
					{
						$sb .= substr($str, 0, $i);
					}
				}
				if ($c == '\\')
				{
					$sb.="\\x5C";
				}
				else if ($c == '"')
				{
					$sb.="\\x22";
				}
				else if ($c == '\'')
				{
					$sb.="\\x27";
				}
				else if ($c == '\r')
				{
					$sb.="\\x0D";
				}
				else if ($c == '\n')
				{
					$sb.="\\x0A";
				}
				else if ($c == '<')
				{
					$sb.="\\x3C";
				}
				else if ($c == '>')
				{
					$sb.="\\x3E";
				}
				else if ($c == '&')
				{
					$sb.="\\x26";
				}
				else
				{
					$code = $c;
					$a1 = $code & 0xF;
					$a2 = ($code & 0xF0) / 0x10;
					$sb.="\\x";
					$sb.=$chars[$a2];
					$sb.=$chars[$a1];
				}
			}
			else if ($sb != "")
			{
				$sb .= $c;
			}
		}
		if ($sb != "")
			return $sb;
		return $str;
	}
}
?>
